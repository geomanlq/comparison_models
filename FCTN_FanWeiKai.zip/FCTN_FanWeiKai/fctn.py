import torch
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error
from tqdm import tqdm

# 1. 读取 txt 文件
def load_txt(path):
    with open(path, 'r') as f:
        lines = f.readlines()
    data = [list(map(float, line.strip().split())) for line in lines]
    return torch.tensor(np.array(data), dtype=torch.float32)

# 2. 构建稀疏张量索引和值
def build_sparse_tensor(data):
    indices = data[:, :3].long()
    values = data[:, 3]
    return indices, values

# 3. F3TN 模型
class F3TN(torch.nn.Module):
    def __init__(self, I, J, N, f):
        super().__init__()
        self.Gx = torch.nn.Parameter(torch.randn(I, f, f) * 0.01)
        self.Gy = torch.nn.Parameter(torch.randn(f, J, f) * 0.01)
        self.Gz = torch.nn.Parameter(torch.randn(f, f, N) * 0.01)

    def forward(self, i, j, t):
        """
        i,j,t : 1-D long tensor, 长度 = batch_size
        返回   : [batch_size] 的预测值
        """
        # 取 batch 因子
        Gx_b = self.Gx[i]                          # [B, f, f]
        Gy_b = self.Gy[:, j, :]                    # [f, B, f]
        Gz_b = self.Gz[:, :, t]                    # [f, f, B]

        # 先收缩 p,q
        temp = torch.einsum('bpq,qbr->bpr', Gx_b, Gy_b)   # [B, f, f]
        # 再收缩 r
        out  = torch.einsum('bpr,prb->b', temp, Gz_b)     # [B]
        return out

# 4. 训练函数（带验证集评估）
def train(model,
          train_indices, train_values,
          val_indices, val_values,
          test_indices, test_values,
          epochs=200,
          batch_size=1024,
          lr=1e-4,            # 初始放大
          lambda1=1e-8,       # L1 减弱
          lambda2=1e-8,       # L2 减弱
          patience=10):       # early-stop
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, verbose=True)
    n = train_indices.shape[0]
    best_val_mae = float('inf')
    bad_epoch = 0

    for epoch in tqdm(range(epochs)):
        model.train()
        perm = torch.randperm(n)
        train_indices = train_indices[perm]
        train_values = train_values[perm]
        total_loss = 0.
        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            idx = train_indices[start:end]
            val = train_values[start:end]
            i, j, t = idx[:, 0], idx[:, 1], idx[:, 2]
            pred = model(i, j, t)
            loss = torch.mean((pred - val) ** 2)
            reg1 = lambda1 * (model.Gx.abs().sum() + model.Gy.abs().sum() + model.Gz.abs().sum())
            reg2 = lambda2 * (model.Gx.pow(2).sum() + model.Gy.pow(2).sum() + model.Gz.pow(2).sum())
            loss = loss + reg1 + reg2
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        # 每轮测验证 + 测试
        model.eval()
        val_mae, val_rmse = evaluate(model, val_indices, val_values)
        test_mae, test_rmse = evaluate(model, test_indices, test_values)
        print(f"Epoch {epoch:03d} | Loss {total_loss:.4f} | "
              f"Val MAE {val_mae:.4f} RMSE {val_rmse:.4f} | "
              f"Test MAE {test_mae:.4f} RMSE {test_rmse:.4f}")

        scheduler.step(val_mae)

        # early-stopping
        if val_mae < best_val_mae:
            best_val_mae = val_mae
            bad_epoch = 0
            torch.save(model.state_dict(), "best_fctn.pt")  # 保存最优
        else:
            bad_epoch += 1
            if bad_epoch >= patience:
                print("Early stopped @ epoch", epoch)
                break

    # 回载最优模型
    model.load_state_dict(torch.load("best_fctn.pt"))

# 5. 评估函数
def evaluate(model, indices, values):
    with torch.no_grad():
        i, j, t = indices[:, 0], indices[:, 1], indices[:, 2]
        pred = model(i, j, t).cpu().numpy()
        true = values.cpu().numpy()
        mae = mean_absolute_error(true, pred)
        rmse = np.sqrt(mean_squared_error(true, pred))
        return mae, rmse

# 6. 主函数
def main():
    train_data = load_txt(r'E:\dataset\pems03\train_norm.txt')
    val_data = load_txt(r'E:\dataset\pems03\val_norm.txt')
    test_data = load_txt(r'E:\dataset\pems03\test_norm.txt')

    I = max(int(train_data[:, 0].max()), int(val_data[:, 0].max()), int(test_data[:, 0].max())) + 1
    J = max(int(train_data[:, 1].max()), int(val_data[:, 1].max()), int(test_data[:, 1].max())) + 1
    N = max(int(train_data[:, 2].max()), int(val_data[:, 2].max()), int(test_data[:, 2].max())) + 1
    f = 20  # 潜变量维度

    train_indices, train_values = build_sparse_tensor(train_data)
    val_indices, val_values = build_sparse_tensor(val_data)
    test_indices, test_values = build_sparse_tensor(test_data)

    model = F3TN(I, J, N, f)
    train(model, train_indices, train_values,
          val_indices, val_values,
          test_indices, test_values)

    test_mae, test_rmse = evaluate(model, test_indices, test_values)
    print(f"Final Test MAE: {test_mae:.4f}, RMSE: {test_rmse:.4f}")

if __name__ == '__main__':
    main()